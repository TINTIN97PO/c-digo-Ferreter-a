
package com.mycompany.ventanasproyectofacu;


public class ProyectoFacuFerreteria {

    public static void main(String[] args) {
       
       Logging principal = new Logging();
       principal.setVisible(true);
    }
}
/**
 * Para hacer la base de datos Use un programa llamado XAMPP y PHPmyAdmin
 * hice todas las tablas pero todavia no pude enlazarlas, en la ultima entrega
 * las voy a presentar
 */